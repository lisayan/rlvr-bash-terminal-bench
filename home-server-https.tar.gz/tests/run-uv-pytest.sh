#!/bin/bash

pytest $TEST_DIR/test_outputs.py -rA
