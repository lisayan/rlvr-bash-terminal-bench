"""
Terminal-Bench task for debugging pandas version dependency issues.
"""
