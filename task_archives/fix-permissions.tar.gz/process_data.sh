#!/bin/bash

echo "Data processed successfully!" 