#!/bin/bash
source /activate-conda.sh
exec "$@"